import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denominasi',
  templateUrl: './denominasi.component.html',
  styleUrls: ['./denominasi.component.css']
})
export class DenominasiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
