import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashdrawer-head-teller',
  templateUrl: './cashdrawer-head-teller.component.html',
  styleUrls: ['./cashdrawer-head-teller.component.css']
})
export class CashdrawerHeadTellerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
