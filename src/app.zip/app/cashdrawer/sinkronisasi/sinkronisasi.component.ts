import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sinkronisasi',
  templateUrl: './sinkronisasi.component.html',
  styleUrls: ['./sinkronisasi.component.css']
})
export class SinkronisasiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
