import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daftarrekening',
  templateUrl: './daftarrekening.component.html',
  styleUrls: ['./daftarrekening.component.css']
})
export class DaftarrekeningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
