import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cetakrekening',
  templateUrl: './cetakrekening.component.html',
  styleUrls: ['./cetakrekening.component.css']
})
export class CetakrekeningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
