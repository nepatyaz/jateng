import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bayar-pkb',
  templateUrl: './bayar-pkb.component.html',
  styleUrls: ['./bayar-pkb.component.css']
})
export class BayarPKBComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
