import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billpayment',
  templateUrl: './billpayment.component.html',
  styleUrls: ['./billpayment.component.css']
})
export class BillpaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
