import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bayar-mpn',
  templateUrl: './bayar-mpn.component.html',
  styleUrls: ['./bayar-mpn.component.css']
})
export class BayarMPNComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
