import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ulang-passbook',
  templateUrl: './ulang-passbook.component.html',
  styleUrls: ['./ulang-passbook.component.css']
})
export class UlangPassbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
