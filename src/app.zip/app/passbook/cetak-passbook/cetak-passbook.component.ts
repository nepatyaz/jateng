import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cetak-passbook',
  templateUrl: './cetak-passbook.component.html',
  styleUrls: ['./cetak-passbook.component.css']
})
export class CetakPassbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
