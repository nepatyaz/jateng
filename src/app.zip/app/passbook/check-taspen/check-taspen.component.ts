import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-check-taspen',
  templateUrl: './check-taspen.component.html',
  styleUrls: ['./check-taspen.component.css']
})
export class CheckTaspenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
