import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-passbook',
  templateUrl: './header-passbook.component.html',
  styleUrls: ['./header-passbook.component.css']
})
export class HeaderPassbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
