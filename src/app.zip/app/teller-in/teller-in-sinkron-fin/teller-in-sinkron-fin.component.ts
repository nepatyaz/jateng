import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-sinkron-fin',
  templateUrl: './teller-in-sinkron-fin.component.html',
  styleUrls: ['./teller-in-sinkron-fin.component.css']
})
export class TellerInSinkronFinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
