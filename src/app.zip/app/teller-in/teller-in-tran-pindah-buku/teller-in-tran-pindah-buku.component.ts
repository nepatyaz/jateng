import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-tran-pindah-buku',
  templateUrl: './teller-in-tran-pindah-buku.component.html',
  styleUrls: ['./teller-in-tran-pindah-buku.component.css']
})
export class TellerInTranPindahBukuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
