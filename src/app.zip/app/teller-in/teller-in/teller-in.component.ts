import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in',
  templateUrl: './teller-in.component.html',
  styleUrls: ['./teller-in.component.css']
})
export class TellerInComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
