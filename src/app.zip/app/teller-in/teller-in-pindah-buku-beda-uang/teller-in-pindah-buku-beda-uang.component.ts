import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-pindah-buku-beda-uang',
  templateUrl: './teller-in-pindah-buku-beda-uang.component.html',
  styleUrls: ['./teller-in-pindah-buku-beda-uang.component.css']
})
export class TellerInPindahBukuBedaUangComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
