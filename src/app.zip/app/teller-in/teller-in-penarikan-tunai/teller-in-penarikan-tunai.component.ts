import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-penarikan-tunai',
  templateUrl: './teller-in-penarikan-tunai.component.html',
  styleUrls: ['./teller-in-penarikan-tunai.component.css']
})
export class TellerInPenarikanTunaiComponent implements OnInit {

  constructor() {}
  ngOnInit() {
  }

}
