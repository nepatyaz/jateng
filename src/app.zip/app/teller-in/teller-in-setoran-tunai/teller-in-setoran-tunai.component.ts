import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-setoran-tunai',
  templateUrl: './teller-in-setoran-tunai.component.html',
  styleUrls: ['./teller-in-setoran-tunai.component.css']
})
export class TellerInSetoranTunaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  } 

}
