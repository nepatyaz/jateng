import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller-in-selisih-kas',
  templateUrl: './teller-in-selisih-kas.component.html',
  styleUrls: ['./teller-in-selisih-kas.component.css']
  
})
export class TellerInSelisihKasComponent implements OnInit {
  constructor() { }
  ngOnInit() {
  }

}
