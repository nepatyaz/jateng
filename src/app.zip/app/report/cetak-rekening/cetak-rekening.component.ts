import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cetak-rekening',
  templateUrl: './cetak-rekening.component.html',
  styleUrls: ['./cetak-rekening.component.css']
})
export class ReportCetakRekeningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
