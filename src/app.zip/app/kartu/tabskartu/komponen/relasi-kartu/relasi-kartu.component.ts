import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'relasi-kartu',
  templateUrl: './relasi-kartu.component.html',
  styleUrls: ['./relasi-kartu.component.css']
})
export class RelasiKartuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
