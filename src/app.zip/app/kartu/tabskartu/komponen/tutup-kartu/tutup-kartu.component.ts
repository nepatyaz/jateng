import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'tutup-kartu',
  templateUrl: './tutup-kartu.component.html',
  styleUrls: ['./tutup-kartu.component.css']
})
export class TutupKartuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
