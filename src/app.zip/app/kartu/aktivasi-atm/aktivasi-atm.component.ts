import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aktivasi-atm',
  templateUrl: './aktivasi-atm.component.html',
  styles: []
})
export class AktivasiAtmComponent implements OnInit {

    constructor() { } 

    ngOnInit(){}
    
  }
