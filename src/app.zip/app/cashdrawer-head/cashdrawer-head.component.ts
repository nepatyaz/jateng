import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cashdrawer-head',
  templateUrl: './cashdrawer-head.component.html',
  styleUrls: ['./cashdrawer-head.component.css']
})
export class CashdrawerHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
