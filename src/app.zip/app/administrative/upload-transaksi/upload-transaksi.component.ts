import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-transaksi',
  templateUrl: './upload-transaksi.component.html',
  styleUrls: ['./upload-transaksi.component.css']
})
export class UploadTransaksiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
