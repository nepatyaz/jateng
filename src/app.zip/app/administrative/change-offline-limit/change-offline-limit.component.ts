import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-offline-limit',
  templateUrl: './change-offline-limit.component.html',
  styleUrls: ['./change-offline-limit.component.css']
})
export class ChangeOfflineLimitComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
