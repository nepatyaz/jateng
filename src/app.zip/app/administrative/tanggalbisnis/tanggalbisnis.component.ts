import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tanggalbisnis',
  templateUrl: './tanggalbisnis.component.html',
  styleUrls: ['./tanggalbisnis.component.css']
})
export class TanggalbisnisComponent implements OnInit {

  constructor() {}
  ngOnInit() {
  }

}
