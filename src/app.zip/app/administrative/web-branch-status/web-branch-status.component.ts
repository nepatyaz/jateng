import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-web-branch-status',
  templateUrl: './web-branch-status.component.html',
  styleUrls: ['./web-branch-status.component.css']
})
export class WebBranchStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
