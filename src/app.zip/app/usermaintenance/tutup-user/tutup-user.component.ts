import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutup-user',
  templateUrl: './tutup-user.component.html',
  styleUrls: ['./tutup-user.component.css']
})
export class TutupUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
