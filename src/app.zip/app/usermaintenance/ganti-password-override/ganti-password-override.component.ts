import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ganti-password-override',
  templateUrl: './ganti-password-override.component.html',
  styleUrls: ['./ganti-password-override.component.css']
})
export class GantiPasswordOverrideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
