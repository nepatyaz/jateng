import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ganti-password',
  templateUrl: './ganti-password.component.html',
  styleUrls: ['./ganti-password.component.css']
})
export class GantiPasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
