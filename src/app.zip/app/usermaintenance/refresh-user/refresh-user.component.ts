import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refresh-user',
  templateUrl: './refresh-user.component.html',
  styleUrls: ['./refresh-user.component.css']
})
export class RefreshUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
