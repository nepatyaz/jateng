import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cari-baru-user',
  templateUrl: './cari-baru-user.component.html',
  styleUrls: ['./cari-baru-user.component.css']
})
export class CariBaruUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
