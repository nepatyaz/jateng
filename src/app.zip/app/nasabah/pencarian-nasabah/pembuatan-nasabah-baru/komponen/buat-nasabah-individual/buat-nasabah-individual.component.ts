import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buat-nasabah-individual',
  templateUrl: './buat-nasabah-individual.component.html',
  styleUrls: ['./buat-nasabah-individual.component.css']
})
export class BuatNasabahIndividualComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
