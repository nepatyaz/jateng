import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-duplikat-nasabah-indvl',
  templateUrl: './duplikat-nasabah-indvl.component.html',
  styleUrls: ['./duplikat-nasabah-indvl.component.css']
})
export class DuplikatNasabahIndvlComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
