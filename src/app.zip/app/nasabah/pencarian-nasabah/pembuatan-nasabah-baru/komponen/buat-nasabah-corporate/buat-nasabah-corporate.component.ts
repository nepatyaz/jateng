import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buat-nasabah-corporate',
  templateUrl: './buat-nasabah-corporate.component.html',
  styleUrls: ['./buat-nasabah-corporate.component.css']
})
export class BuatNasabahCorporateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
