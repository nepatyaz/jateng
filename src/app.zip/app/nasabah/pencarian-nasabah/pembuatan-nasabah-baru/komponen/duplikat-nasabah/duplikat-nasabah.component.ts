import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-duplikat-nasabah',
  templateUrl: './duplikat-nasabah.component.html',
  styleUrls: ['./duplikat-nasabah.component.css']
})
export class DuplikatNasabahComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
