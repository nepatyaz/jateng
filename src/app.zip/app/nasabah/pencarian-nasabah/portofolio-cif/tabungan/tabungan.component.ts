import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabungan',
  templateUrl: './tabungan.component.html',
  styleUrls: ['./tabungan.component.css']
})
export class TabunganComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
