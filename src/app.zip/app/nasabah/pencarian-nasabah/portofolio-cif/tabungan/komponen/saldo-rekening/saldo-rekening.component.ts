import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saldo-rekening',
  templateUrl: './saldo-rekening.component.html',
  styles: []
})
export class SaldoRekeningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
