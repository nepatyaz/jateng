import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mutasi',
  templateUrl: './mutasi.component.html',
  styles: []
})
export class MutasiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
