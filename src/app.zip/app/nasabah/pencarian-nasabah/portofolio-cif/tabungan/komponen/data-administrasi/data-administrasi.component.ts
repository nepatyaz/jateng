import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-administrasi',
  templateUrl: './data-administrasi.component.html',
  styles: []
})
export class DataAdministrasiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
