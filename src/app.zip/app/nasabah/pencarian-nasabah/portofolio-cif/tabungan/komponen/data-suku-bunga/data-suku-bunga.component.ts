import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-suku-bunga',
  templateUrl: './data-suku-bunga.component.html',
  styles: []
})
export class DataSukuBungaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
