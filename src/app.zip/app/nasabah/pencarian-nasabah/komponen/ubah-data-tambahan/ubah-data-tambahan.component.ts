import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ubah-data-tambahan',
  templateUrl: './ubah-data-tambahan.component.html',
  styles: []
})
export class UbahDataTambahanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
