import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daftar-kode-nasabah',
  templateUrl: './daftar-kode-nasabah.component.html',
  styleUrls: ['./daftar-kode-nasabah.component.css']
})
export class DaftarKodeNasabahComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
